# Reviewed Euronext CSD evidence pack

Base operational review: **2026-09-13**. Additional reviewed sections carry their own review date
(currently 2026-09-13, 2026-09-14); the 14 September 2026 date covers the scoped release-publication
update and the settlement-expert-agent snapshot admitted the same day.
124 distinct reviewed sections from 51 source identities.

## Import and retrieval

Start with [13 September current evidence](retrieval/exports/2026-09-13/current.jsonl).
The 14 September exports contain the November final-publication section and the
settlement-agent snapshot sections reviewed on that date (65 current,
26 reference, 11 future).
Choose one exact review date and mode before ingestion; sections never mix review dates through dependencies.
The combined top-level mode files contain 82 current,
37 reference and 15 future sections and require
the same date filtering. Some sections occur in more than one permitted mode.
Consult [the section index](retrieval/README.md) for permitted question types.

Uploading this pack does not enforce retrieval controls. The receiving system must
require the evidence date, entity, service, actor role, question type and mode;
apply those filters before retrieval, including exact `verified_as_of`; include
every dependency; enforce required context, subject/platform release, event scope,
calendar intervals and applicability basis; and preserve
limitations and source-language/approval qualifications. Block unsupported
questions. Never widen an excerpt into permission to use a whole manual.

Use the section decisions and source register as policy/provenance, not extra
answer evidence. Citation URLs and PDF/article locators point to the original
authorities. Source paths in the metadata refer to the full local workspace;
original manuals are deliberately absent from this pack. The two matching
diagram images support their reviewed functional transcription only.

This is an ingestion bundle, not a standalone executable retriever. The full
workspace supplies `scripts/retrieve_evidence.py`, context checks, originals and
source-hash verification. Do not treat package hashes as authority signatures.
No unrestricted full-document starter pack or AI-written guide is admitted here.

## Dates, scope and known gaps

Revalidate official sources and applicable notices before advancing the snapshot
date. Future laws/releases are never promoted solely because time passed.
Milan participant cut-offs, unconditional Oslo edition approval, independent
Athens approval, exact production fields/entitlements, actual ISIN eligibility
and complete reporting/tax/fee procedures remain unresolved where governing
evidence is missing or unreviewed. The full workspace's dependency register
records all 17 audit dependencies and their partial or unresolved outcomes.

The matching diagrams are functional descriptions, not certified XML schemas.
T2S-native messages are not local participant-interface specifications.
Reviewed dated ECB event overlays exist only for the business dates and currencies
listed in the section index (8 September 2026 EUR at the 13 September review; the 2026
status-history dates and the routine-only date list at the 14 September review).
Any schedule reached directly or through a dependency needs a matching overlay
for an actual-date query. An explicitly nominal request uses `schedule_kind: baseline`;
dated questions otherwise default to actual. A publication description is not proof
of operative requirements. The November final delivery does not certify deployment.

## Verification

113/113 explicit routing cases and
39/39 integrity/control checks passed.
The preserved adversarial cases passed 31/31,
plus 31/31 repair-specific checks.
800 original documents were preserved.
Routing cases with an expected block correctly blocked evidence selection (27 cases).
LLM answer quality was not tested; no hosted answer service is included.

`PACKAGE-MANIFEST.json` hashes every other member of this archive. It is a
transport integrity manifest, distinct from the full workspace build manifest.
Verification metadata records the full workspace build that was tested.
