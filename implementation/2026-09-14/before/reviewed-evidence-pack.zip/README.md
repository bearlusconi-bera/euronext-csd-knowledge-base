# Reviewed Euronext CSD evidence pack

Evidence snapshot: **2026-09-13**. Implementation: 14 September 2026.
30 distinct reviewed sections from 24 source identities.

## Import and retrieval

Start with [current evidence](retrieval/exports/current.jsonl) (17 sections).
Keep [reference evidence](retrieval/exports/reference.jsonl) (11 sections)
and [future evidence](retrieval/exports/future.jsonl) (4 sections) in separate
collections. Some sections occur in more than one permitted mode.
Consult [the section index](retrieval/README.md) for permitted question types.

Uploading this pack does not enforce retrieval controls. The receiving system must
require the evidence date, entity, service, actor role, question type and mode;
apply those filters before retrieval; include every dependency; enforce each
section's required context and release/effective-period constraints; and preserve
limitations and source-language/approval qualifications. Block unsupported
questions. Never widen an excerpt into permission to use a whole manual.

Use the section decisions and source register as policy/provenance, not extra
answer evidence. Citation URLs and PDF/article locators point to the original
authorities. Source paths in the metadata refer to the full local workspace;
original manuals are deliberately absent from this pack. The two matching
diagram images support their reviewed functional transcription only.

This is an ingestion bundle, not a standalone executable retriever. The full
workspace supplies `scripts/retrieve_evidence.py`, context checks, originals and
source-hash verification. Do not treat package hashes as authority signatures.
No unrestricted full-document starter pack or AI-written guide is admitted here.

## Dates, scope and known gaps

Revalidate official sources and applicable notices before advancing the snapshot
date. Future laws/releases are never promoted solely because time passed.
Milan participant cut-offs, unconditional Oslo edition approval, independent
Athens approval, exact production fields/entitlements, actual ISIN eligibility
and complete reporting/tax/fee procedures remain unresolved where governing
evidence is missing or unreviewed. The full workspace's dependency register
records all 17 audit dependencies and their partial or unresolved outcomes.

The matching diagrams are functional descriptions, not certified XML schemas.
T2S-native messages are not local participant-interface specifications.
The reviewed dated ECB event overlay covers 8 September 2026 EUR only.

## Verification

34/34 explicit routing cases and
39/39 integrity/control checks passed.
800 original documents were preserved.
Six unsupported routing cases correctly blocked evidence selection.
LLM answer quality was not tested; no hosted answer service is included.

`PACKAGE-MANIFEST.json` hashes every other member of this archive. It is a
transport integrity manifest, distinct from the full workspace build manifest.
Verification metadata records the full workspace build that was tested.
